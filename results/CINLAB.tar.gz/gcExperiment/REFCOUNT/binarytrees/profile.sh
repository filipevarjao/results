#!/bin/bash
output_file="sar_data_binarytrees_7.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
GOGC=off go run binarytrees.go 7

kill $pid
echo "\n ThEnd"
time: 7.09527ms | TotalAlloc 337736 | mallocs 8910 | frees 8909 | GC cycles  0

 ThEnd
