#!/bin/bash
output_file="sar_data_binarytrees_14.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
GOMAXPROCS=1 ./a.out 14

kill $pid
echo "\n ThEnd"
time: 299.864ms | TotalAlloc 51815824 | mallocs 3222415 | frees 65744 | GC cycles  73

 ThEnd
