#!/bin/bash
output_file="sar_data_binarytrees_21.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
./a.out 21

kill $pid
echo "\n ThEnd"
time: 59.786813s | TotalAlloc 9839237936 | mallocs 613778575 | frees 10497822 | GC cycles  125
