#!/bin/bash
output_file="sar_data_binarytrees_14.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
go run binarytrees.go 14

kill $pid
echo "\n ThEnd"
time: 287.907382ms | TotalAlloc 51620096 | mallocs 3222329 | frees 163964 | GC cycles  14

 ThEnd
