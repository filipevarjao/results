#!/bin/bash
output_file="sar_data_binarytrees_14.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
GOMAXPROCS=1 go run binarytrees.go 14

kill $pid
echo "\n ThEnd"
time: 221.247636ms | TotalAlloc 51582096 | mallocs 3222294 | frees 238657 | GC cycles  14

 ThEnd
