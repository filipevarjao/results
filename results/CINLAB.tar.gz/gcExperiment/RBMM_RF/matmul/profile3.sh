#!/bin/bash
#Script Variables
output_file="sar_data_5000.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run matmul_v1.go 5000

GOGC=off ./a.out 5000
kill $pid

echo "\n ThEnd"
time: 12m4.956265s | TotalAlloc 22272 | mallocs 115 | frees 115 | GC cycles  0

 ThEnd
