#!/bin/bash
#Script Variables
output_file="sar_data_100.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run matmul_v1.go 5000

./a.out 100
kill $pid

echo "\n ThEnd"
time: 4.271ms | TotalAlloc 437112 | mallocs 522 | frees 507 | GC cycles  4
