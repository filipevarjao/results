#!/bin/bash
output_file="sar_data_binarytrees_21.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
./a.out 21

kill $pid
echo "\n ThEnd"
time: 35.829092s | TotalAlloc 9840111632 | mallocs 613778479 | frees 8400575 | GC cycles  124
