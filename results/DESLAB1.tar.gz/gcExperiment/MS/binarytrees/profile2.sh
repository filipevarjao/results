#!/bin/bash
output_file="sar_data_binarytrees_14.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
go run binarytrees.go 14

kill $pid
echo "\n ThEnd"
time: 104.497715ms | TotalAlloc 51636688 | mallocs 3222347 | frees 163981 | GC cycles  14

 ThEnd
