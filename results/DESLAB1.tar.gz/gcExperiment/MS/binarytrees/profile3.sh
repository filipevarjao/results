#!/bin/bash
output_file="sar_data_binarytrees_21.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
go run binarytrees.go 21

kill $pid
echo "\n ThEnd"
time: 24.926444973s | TotalAlloc 9820350176 | mallocs 613766669 | frees 6291618 | GC cycles  144

 ThEnd
