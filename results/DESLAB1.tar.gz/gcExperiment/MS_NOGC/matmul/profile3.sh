#!/bin/bash
#Script Variables
output_file="sar_data_5000.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run matmul_v1.go 5000

GOGC=off go run matmul_v1.go 5000
kill $pid

echo "\n ThEnd"
time: 1m58.555771245s | TotalAlloc 819756832 | mallocs 20120 | frees 20117 | GC cycles  0

 ThEnd
