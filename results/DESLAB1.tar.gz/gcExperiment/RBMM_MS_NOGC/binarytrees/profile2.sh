#!/bin/bash
output_file="sar_data_binarytrees_14.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
GOGC=off ./a.out 14

kill $pid
echo "\n ThEnd"
time: 57.514ms | TotalAlloc 22264 | mallocs 115 | frees 115 | GC cycles  0

 ThEnd
