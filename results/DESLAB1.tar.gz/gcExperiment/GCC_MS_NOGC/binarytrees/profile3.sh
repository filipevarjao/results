#!/bin/bash
output_file="sar_data_binarytrees_21.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
GOGC=off ./a.out 21

kill $pid
echo "\n ThEnd"
time: 1m18.152801s | TotalAlloc 10522389728 | mallocs 613788559 | frees 613788553 | GC cycles  0
