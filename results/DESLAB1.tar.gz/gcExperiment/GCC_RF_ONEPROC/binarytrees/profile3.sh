#!/bin/bash
output_file="sar_data_binarytrees_21.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
GOGC=off GOMAXPROCS=1 ./a.out 21

kill $pid
echo "\n ThEnd"
time: 1m15.311965s | TotalAlloc 10522018128 | mallocs 613788727 | frees 613788721 | GC cycles  0

 ThEnd
