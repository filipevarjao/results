#!/bin/bash
output_file="sar_data_binarytrees_14.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
./a.out 14

kill $pid
echo "\n ThEnd"
time: 292.741ms | TotalAlloc 51812112 | mallocs 3222399 | frees 65728 | GC cycles  73
