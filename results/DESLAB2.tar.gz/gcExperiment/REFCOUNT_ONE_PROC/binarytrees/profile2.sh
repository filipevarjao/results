#!/bin/bash
output_file="sar_data_binarytrees_14.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
GOGC=off GOMAXPROCS=1 go run binarytrees.go 14

kill $pid
echo "\n ThEnd"
time: 344.828637ms | TotalAlloc 103137704 | mallocs 3222292 | frees 3222291 | GC cycles  0

 ThEnd
