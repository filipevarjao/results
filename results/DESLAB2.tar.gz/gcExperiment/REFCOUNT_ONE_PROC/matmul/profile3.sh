#!/bin/bash
#Script Variables
output_file="sar_data_5000.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run matmul_v1.go 5000

GOGC=off GOMAXPROCS=1 go run matmul_v1.go 5000
kill $pid

echo "\n ThEnd"
time: 3m15.262467859s | TotalAlloc 819719176 | mallocs 20106 | frees 20105 | GC cycles  0

 ThEnd
