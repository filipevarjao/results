#!/bin/bash
output_file="sar_data_binarytrees_21.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run binarytrees.go 21
go run binarytrees.go 21

kill $pid
echo "\n ThEnd"
time: 24.618336564s | TotalAlloc 9820345904 | mallocs 613766657 | frees 6291606 | GC cycles  146

 ThEnd
