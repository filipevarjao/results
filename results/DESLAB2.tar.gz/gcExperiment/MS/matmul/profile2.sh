#!/bin/bash
#Script Variables
output_file="sar_data_1000.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run matmul_v1.go 5000

go run matmul_v1.go 1000
kill $pid

echo "\n ThEnd"
time: 802.190682ms | TotalAlloc 32943728 | mallocs 4151 | frees 3139 | GC cycles  4

 ThEnd
