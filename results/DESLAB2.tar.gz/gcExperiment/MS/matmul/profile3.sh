#!/bin/bash
#Script Variables
output_file="sar_data_5000.txt"
interval=1

LC_ALL=C sar -bBdqrRSvwWy -I SUM -I XALL -u ALL -P ALL $interval  > $output_file &
pid=$!

sleep 1

#GOGC=off go run matmul_v1.go 5000

go run matmul_v1.go 5000
kill $pid

echo "\n ThEnd"
time: 1m48.745889304s | TotalAlloc 819769152 | mallocs 20152 | frees 20141 | GC cycles  8

 ThEnd
time: 1m47.762626456s | TotalAlloc 819768928 | mallocs 20151 | frees 20140 | GC cycles  8

 ThEnd
